// نظام حفظ التقدم عبر localStorage مع تحمّل فشل التخزين أو تعطيله.

const KEY = 'athar3d.save.v1';

const DEFAULT_STATE = {
  echoesFound: {},      // { echoId: true }
  puzzlePowered: false, // الآلية الخفية فُعّلت
  puzzleSolved: false,
  gateOpen: false,
  settings: {
    audio: true,
    sensitivity: 1,     // 0.6 | 1 | 1.6
    quality: 'medium',  // low | medium | high
  },
};

let storageOk = true;
try {
  const probe = '__athar_probe__';
  window.localStorage.setItem(probe, '1');
  window.localStorage.removeItem(probe);
} catch (e) {
  storageOk = false;
}

export const storageAvailable = storageOk;

export function loadState() {
  if (!storageOk) return structuredClone(DEFAULT_STATE);
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return structuredClone(DEFAULT_STATE);
    const parsed = JSON.parse(raw);
    return {
      ...structuredClone(DEFAULT_STATE),
      ...parsed,
      settings: { ...DEFAULT_STATE.settings, ...(parsed.settings || {}) },
    };
  } catch (e) {
    console.warn('[save] تعذّر قراءة الحفظ، سيبدأ التقدم من جديد.', e);
    return structuredClone(DEFAULT_STATE);
  }
}

export function saveState(state) {
  if (!storageOk) return false;
  try {
    window.localStorage.setItem(KEY, JSON.stringify(state));
    return true;
  } catch (e) {
    console.warn('[save] تعذّر الحفظ المحلي.', e);
    return false;
  }
}

export function clearState() {
  if (storageOk) {
    try { window.localStorage.removeItem(KEY); } catch (e) { /* تجاهل */ }
  }
  return structuredClone(DEFAULT_STATE);
}

export function hasProgress(state) {
  return Object.keys(state.echoesFound).length > 0 || state.puzzleSolved || state.gateOpen;
}

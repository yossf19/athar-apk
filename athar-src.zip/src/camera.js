import * as THREE from 'three';

// كاميرا منظور الشخص الثالث: تتبع سلس، تدوير بالسحب، ومنع الدخول في الجدران.
export class ThirdPersonCamera {
  constructor(camera) {
    this.camera = camera;
    this.yaw = 0; // الكاميرا جنوب الشخصية (z أكبر) فتنظر نحو البوابة في الشمال (z سالب)
    this.pitch = 0.42;  // زاوية الارتفاع (بالراديان)
    this.distance = 6.5;
    this.height = 1.6;
    this.sensitivity = 1;
    this.target = new THREE.Vector3();
    this.current = new THREE.Vector3();
    this.initialized = false;
    this._ray = new THREE.Vector3();
  }

  // سحب الشاشة يدوّر الزاوية؛ dx/dy بالبكسل
  rotate(dx, dy) {
    const k = 0.0045 * this.sensitivity;
    this.yaw -= dx * k;
    this.pitch = THREE.MathUtils.clamp(this.pitch + dy * k, 0.12, 1.1);
  }

  setAspect(aspect) {
    this.camera.aspect = aspect;
    this.camera.updateProjectionMatrix();
  }

  // تحديث الموقع بعد تحرك الشخصية
  update(dt, playerPos, colliders) {
    const focusX = playerPos.x;
    const focusY = playerPos.y + this.height;
    const focusZ = playerPos.z;
    this.target.set(focusX, focusY, focusZ);

    // الموضع المثالي خلف الشخصية حسب الزاوية
    const cosP = Math.cos(this.pitch), sinP = Math.sin(this.pitch);
    let dist = this.distance;

    // منع الدخول في الجدران: تقصير المسافة إذا تقاطع الخط مع صندوق تصادم
    for (let i = 1; i <= 12; i++) {
      const t = i / 12;
      const px = focusX + Math.sin(this.yaw) * cosP * this.distance * t;
      const pz = focusZ + Math.cos(this.yaw) * cosP * this.distance * t;
      const py = focusY + sinP * this.distance * t;
      if (py < 0.25 || this.insideAny(px, pz, colliders)) {
        dist = Math.max(1.2, this.distance * (t - 0.1));
        break;
      }
    }

    const desX = focusX + Math.sin(this.yaw) * cosP * dist;
    const desZ = focusZ + Math.cos(this.yaw) * cosP * dist;
    const desY = Math.max(0.3, focusY + sinP * dist);

    if (!this.initialized) {
      this.current.set(desX, desY, desZ);
      this.initialized = true;
    } else {
      // تتبع سلس بالتخميد الأسي المستقل عن معدل الإطارات
      const k = 1 - Math.exp(-10 * dt);
      this.current.x += (desX - this.current.x) * k;
      this.current.y += (desY - this.current.y) * k;
      this.current.z += (desZ - this.current.z) * k;
    }

    this.camera.position.copy(this.current);
    this.camera.lookAt(this.target);
  }

  insideAny(x, z, colliders) {
    for (const c of colliders) {
      if (x > c.minX - 0.2 && x < c.maxX + 0.2 && z > c.minZ - 0.2 && z < c.maxZ + 0.2) return true;
    }
    return false;
  }

  reset() {
    this.initialized = false;
  }
}

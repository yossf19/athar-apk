// واجهة المستخدم: الشاشات، النصوص، التنبيهات، ولوحة الإشارات.

const $ = (id) => document.getElementById(id);

const screens = ['no-webgl', 'title-screen', 'pause-screen', 'success-screen'];

export const ui = {
  el: {},

  init() {
    const ids = [
      'no-webgl', 'title-screen', 'hud', 'pause-screen', 'success-screen',
      'btn-start', 'btn-continue', 'btn-reset-title', 'btn-pause', 'btn-resume',
      'btn-reset', 'btn-success-close', 'btn-interact', 'btn-replay', 'btn-sens',
      'chapter-name', 'objective', 'interact-hint', 'toast',
      'joystick', 'joystick-knob', 'look-zone',
      'puzzle-panel', 'puzzle-status', 'btn-puzzle-close',
      'set-audio', 'set-sens', 'set-quality',
    ];
    for (const id of ids) this.el[id] = $(id);
    return this;
  },

  show(id) { this.el[id]?.classList.remove('hidden'); },
  hide(id) { this.el[id]?.classList.add('hidden'); },
  setVisible(id, on) { on ? this.show(id) : this.hide(id); },

  showOnly(id) {
    for (const s of screens) this.hide(s);
    if (id) this.show(id);
  },

  setChapter(name, objective) {
    this.el['chapter-name'].textContent = name;
    this.el['objective'].textContent = objective;
  },

  setHint(on, text) {
    const h = this.el['interact-hint'];
    if (text) h.textContent = text;
    this.setVisible('interact-hint', on);
  },

  // رسالة قصيرة تختفي تلقائياً
  toast(message, ms = 3200, tone = '') {
    const t = this.el['toast'];
    t.textContent = message;
    t.style.opacity = '1';
    t.style.borderRight = tone === 'bad' ? '3px solid #ff6b6b' : tone === 'good' ? '3px solid #ffb84d' : '3px solid #7fd8ff';
    this.show('toast');
    clearTimeout(this._toastTimer);
    this._toastTimer = setTimeout(() => {
      t.style.opacity = '0';
      setTimeout(() => this.hide('toast'), 300);
    }, ms);
  },

  setReplayAvailable(on) {
    const b = this.el['btn-replay'];
    b.disabled = !on;
    b.style.opacity = on ? '1' : '0.5';
  },

  setInteractLabel(label) {
    this.el['btn-interact'].textContent = label;
  },

  setSensLabel(value) {
    const label = value <= 0.6 ? 'حساسية: منخفضة' : value >= 1.6 ? 'حساسية: مرتفعة' : 'حساسية: متوسطة';
    this.el['btn-sens'].textContent = label;
  },

  // لوحة الإشارات
  openPuzzle(status, tone = '') {
    this.show('puzzle-panel');
    this.setPuzzleStatus(status, tone);
    this.resetLamps();
  },
  closePuzzle() { this.hide('puzzle-panel'); },
  isPuzzleOpen() { return !this.el['puzzle-panel'].classList.contains('hidden'); },

  setPuzzleStatus(text, tone = '') {
    const p = this.el['puzzle-status'];
    p.textContent = text;
    p.className = 'puzzle-status' + (tone ? ' ' + tone : '');
  },

  flashLamp(index) {
    const btn = document.querySelector(`.lamp-btn[data-lamp="${index}"]`);
    if (!btn) return;
    btn.classList.add('lit');
    setTimeout(() => btn.classList.remove('lit'), 450);
  },

  resetLamps() {
    document.querySelectorAll('.lamp-btn.lit').forEach((b) => b.classList.remove('lit'));
  },

  readSettings() {
    return {
      audio: this.el['set-audio'].checked,
      sensitivity: parseFloat(this.el['set-sens'].value),
      quality: this.el['set-quality'].value,
    };
  },

  writeSettings(s) {
    this.el['set-audio'].checked = !!s.audio;
    this.el['set-sens'].value = String(s.sensitivity);
    this.el['set-quality'].value = s.quality;
  },
};

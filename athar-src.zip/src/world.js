import * as THREE from 'three';

// أبعاد المنطقة: الأرض مربعة من -HALF إلى +HALF
export const HALF = 34;

// جدران كصناديق محورية (AABB) للتصادم: { minX, maxX, minZ, maxZ }
export const colliders = [];

const PALETTE = {
  ground: 0x0c1a2b,
  groundAlt: 0x13263d,
  wall: 0x1d3550,
  wallLight: 0x3a6a8f,
  ruin: 0x27405c,
  metal: 0x7d93a8,
  glow: 0x7fd8ff,
  accent: 0xffb84d,
  white: 0xdfefff,
};

const mats = {};
function mat(key, opts) {
  if (!mats[key]) mats[key] = new THREE.MeshStandardMaterial(opts);
  return mats[key];
}

function addBox(scene, w, h, d, x, y, z, material, collide = true) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), material);
  mesh.position.set(x, y + h / 2, z);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  scene.add(mesh);
  if (collide) {
    colliders.push({ minX: x - w / 2, maxX: x + w / 2, minZ: z - d / 2, maxZ: z + d / 2 });
  }
  return mesh;
}

export function buildWorld(scene, quality) {
  colliders.length = 0;
  const shadows = quality !== 'low';

  // إضاءة سينمائية: ضوء قمري خافت + ضوء تكميلي سماوي
  const moon = new THREE.DirectionalLight(0xbfe6ff, 1.1);
  moon.position.set(-20, 40, 15);
  moon.castShadow = shadows;
  if (shadows) {
    moon.shadow.mapSize.set(1024, 1024);
    moon.shadow.camera.left = -40;
    moon.shadow.camera.right = 40;
    moon.shadow.camera.top = 40;
    moon.shadow.camera.bottom = -40;
    moon.shadow.bias = -0.0005;
  }
  scene.add(moon);
  scene.add(new THREE.HemisphereLight(0x8fbfe6, 0x0a0f18, 0.55));

  const glowLight = new THREE.PointLight(PALETTE.glow, 1.4, 14, 2);
  glowLight.position.set(10, 2.5, 4);
  scene.add(glowLight);

  // الأرضية بنمط شطرنجي خفيف (لون ثانوي واحد فقط)
  const groundGeo = new THREE.PlaneGeometry(HALF * 2, HALF * 2, 1, 1);
  const ground = new THREE.Mesh(groundGeo, mat('ground', { color: PALETTE.ground, roughness: 0.92, metalness: 0.05 }));
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = shadows;
  scene.add(ground);

  const tileCount = quality === 'low' ? 0 : 10;
  if (tileCount) {
    const tileGeo = new THREE.PlaneGeometry(HALF * 2 / tileCount, HALF * 2 / tileCount);
    const tileMat = mat('tile', { color: PALETTE.groundAlt, roughness: 0.8, metalness: 0.1 });
    const tiles = new THREE.InstancedMesh(tileGeo, tileMat, tileCount * tileCount);
    const m = new THREE.Matrix4();
    let i = 0;
    const step = HALF * 2 / tileCount;
    for (let x = 0; x < tileCount; x++) {
      for (let z = 0; z < tileCount; z++) {
        if ((x + z) % 2 === 0) {
          m.makeRotationX(-Math.PI / 2);
          m.setPosition(-HALF + step / 2 + x * step, 0.01, -HALF + step / 2 + z * step);
          tiles.setMatrixAt(i++, m);
        }
      }
    }
    tiles.count = i;
    tiles.receiveShadow = shadows;
    scene.add(tiles);
  }

  // حدود المدينة: جدران خارجية غير مرئية للتصادم فقط
  const B = HALF;
  colliders.push({ minX: -B - 2, maxX: -B, minZ: -B, maxZ: B });
  colliders.push({ minX: B, maxX: B + 2, minZ: -B, maxZ: B });
  colliders.push({ minX: -B, maxX: B, minZ: -B - 2, maxZ: -B });
  colliders.push({ minX: -B, maxX: B, minZ: B, maxZ: B + 2 });

  const wallMat = mat('wall', { color: PALETTE.wall, roughness: 0.7, metalness: 0.2 });
  const wallLightMat = mat('wallLight', { color: PALETTE.wallLight, roughness: 0.5, metalness: 0.3 });
  const ruinMat = mat('ruin', { color: PALETTE.ruin, roughness: 0.95 });

  // مباني متنوعة الارتفاع على جانبي الزقاق الرئيسي (الزقاق على المحور Z بين x=-4..4)
  const buildings = [
    [-14, -22, 7, 6, 9], [-14, -10, 6, 8, 5], [-14, 2, 8, 7, 12],
    [-14, 14, 5, 6, 4], [8, -24, 6, 9, 6], [9, -12, 9, 7, 14],
    [16, 6, 6, 6, 4.5], [10, 14, 7, 6, 8],
  ];
  for (const [x, z, w, d, h] of buildings) {
    addBox(scene, w, h, d, x, 0, z, wallMat);
    addBox(scene, w * 0.85, 0.3, d * 0.85, x, h, z, wallLightMat, false); // حافة علوية
  }

  // حواجز وأطلال منخفضة
  const ruins = [
    [-6, 8, 2.5, 1.2, 1.1], [4, -6, 1.8, 2.2, 0.9], [-2, 18, 3, 1, 1.4],
    [18, -2, 1.2, 4, 1.6], [-18, -28, 4, 1, 1.2],
  ];
  for (const [x, z, w, d, h] of ruins) addBox(scene, w, h, d, x, 0, z, ruinMat);

  // أعمدة مكسورة متفرقة (أطلال) — كمجسمات غير مصادِمة بالكامل للتنوع
  const pillarGeo = new THREE.CylinderGeometry(0.45, 0.55, 4.5, 8);
  for (const [x, z, h] of [[-5, -4, 4.5], [6, 0, 2.2], [-9, 12, 3.1]]) {
    const p = new THREE.Mesh(pillarGeo, ruinMat);
    p.scale.y = h / 4.5;
    p.position.set(x, (h) / 2, z);
    p.castShadow = true;
    scene.add(p);
    colliders.push({ minX: x - 0.5, maxX: x + 0.5, minZ: z - 0.5, maxZ: z + 0.5 });
  }

  // البوابة المعدنية الكبيرة في نهاية الزقاق (عند z = -26)
  const gate = new THREE.Group();
  const gateMat = mat('metal', { color: PALETTE.metal, roughness: 0.35, metalness: 0.85 });
  const frameL = new THREE.Mesh(new THREE.BoxGeometry(1, 7, 1), gateMat);
  frameL.position.set(-3.2, 3.5, 0);
  const frameR = frameL.clone();
  frameR.position.x = 3.2;
  const lintel = new THREE.Mesh(new THREE.BoxGeometry(7.4, 1, 1), gateMat);
  lintel.position.set(0, 7, 0);
  gate.add(frameL, frameR, lintel);

  // ألواح البوابة: تُخفض عند الفتح
  const doorMat = mat('door', { color: 0x4d6378, roughness: 0.4, metalness: 0.8, emissive: 0x06202e, emissiveIntensity: 0.4 });
  const doorL = new THREE.Mesh(new THREE.BoxGeometry(3, 6.2, 0.4), doorMat);
  doorL.position.set(-1.6, 3.1, 0);
  const doorR = doorL.clone();
  doorR.position.x = 1.6;
  gate.add(doorL, doorR);

  // شريط توهج يشير إلى حالة البوابة
  const seamMat = new THREE.MeshBasicMaterial({ color: PALETTE.accent, transparent: true, opacity: 0.8 });
  const seam = new THREE.Mesh(new THREE.BoxGeometry(0.12, 6, 0.1), seamMat);
  seam.position.set(0, 3, 0.25);
  gate.add(seam);

  gate.position.set(0, 0, -26);
  scene.add(gate);
  // تصادم البوابة المغلقة
  colliders.push({ minX: -3.8, maxX: 3.8, minZ: -26.5, maxZ: -25.5 });

  // لوحة التحكم بجانب البوابة
  const panelGroup = new THREE.Group();
  const pedestal = new THREE.Mesh(new THREE.BoxGeometry(1, 1.4, 0.8), mat('ruin', { color: PALETTE.ruin }));
  pedestal.position.y = 0.7;
  panelGroup.add(pedestal);
  const screenMat = new THREE.MeshBasicMaterial({ color: 0x1a3b52 });
  const screen = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.5, 0.05), screenMat);
  screen.position.set(0, 1.45, 0.2);
  screen.rotation.x = -0.35;
  panelGroup.add(screen);

  // أربعة مصابيح إشارة على اللوحة (ألوان مميزة)
  const lampColors = [0x3aa8ff, 0xffffff, 0xffb84d, 0xff6b6b];
  const lamps = [];
  lampColors.forEach((c, idx) => {
    const lampMat = new THREE.MeshStandardMaterial({ color: 0x222a33, emissive: c, emissiveIntensity: 0 });
    const lamp = new THREE.Mesh(new THREE.SphereGeometry(0.09, 12, 10), lampMat);
    lamp.position.set(-0.27 + idx * 0.18, 1.2, 0.42);
    lamp.userData.color = c;
    panelGroup.add(lamp);
    lamps.push(lamp);
  });
  panelGroup.position.set(-3.6, 0, -22.5);
  scene.add(panelGroup);
  colliders.push({ minX: -4.1, maxX: -3.1, minZ: -22.9, maxZ: -22.1 });

  // أدوات بيئية توحي بسكان سابقين: مقاعد، أكياس، ورايات
  const benchMat = mat('wood', { color: 0x4a3a2c, roughness: 0.9 });
  addBox(scene, 2.2, 0.5, 0.7, -10, 0, -5, benchMat);
  addBox(scene, 2.2, 0.5, 0.7, 12, 0, 10, benchMat);
  const flagMat = new THREE.MeshStandardMaterial({ color: 0x9fd7ff, side: THREE.DoubleSide, roughness: 0.9 });
  const flagPole = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 4, 6), wallLightMat);
  flagPole.position.set(-12, 2, 6);
  const flag = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 0.7), flagMat);
  flag.position.set(-11.4, 3.2, 6);
  scene.add(flagPole, flag);

  // منطقة الأثر الزمني: منصة صغيرة في الساحة الجانبية (شرق)
  const platform = new THREE.Mesh(new THREE.CylinderGeometry(2.6, 2.8, 0.25, 24), ruinMat);
  platform.position.set(10, 0.12, 4);
  platform.receiveShadow = shadows;
  scene.add(platform);

  // ضباب خفيف
  scene.fog = new THREE.FogExp2(0x061524, quality === 'low' ? 0.035 : 0.022);
  scene.background = new THREE.Color(0x061524);

  return { gate, doorL, doorR, seam, seamMat, lamps, glowLight, platformX: 10, platformZ: 4 };
}

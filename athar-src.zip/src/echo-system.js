import * as THREE from 'three';

// نظام الآثار الزمنية: تسجيلات منظمة قابلة للتوسعة.
// كل تسجيل = { id, title, position:[x,z], steps:[...] }
// الخطوات:
//   { do:'move',  to:[x,z], dur }   مشي إلى نقطة
//   { do:'wait',  dur }             وقوف
//   { do:'lamp',  index, dur }      إضاءة مصباح على اللوحة (حدث للعالم)
//   { do:'event', name, dur }       حدث عام يُمرَّر للعبة (مثل تفعيل آلية)

export const ECHO_DEFS = [
  {
    id: 'guard',
    title: 'أثر الحارس',
    position: [10, 4],
    clue: 'رأيتَ الحارس يضيء المصابيح بترتيب ثابت، ثم يُطلق آلية خفية عند قاعدة اللوحة.',
    steps: [
      { do: 'wait', dur: 0.8 },
      { do: 'move', to: [10, -2], dur: 2.2 },
      { do: 'move', to: [0, -2], dur: 2.0 },
      { do: 'move', to: [0, -18], dur: 3.4 },
      { do: 'move', to: [-2.4, -21.2], dur: 1.6 },
      { do: 'wait', dur: 0.6 },
      { do: 'event', name: 'mechanism', dur: 1.2 },
      { do: 'lamp', index: 0, dur: 0.9 },
      { do: 'lamp', index: 2, dur: 0.9 },
      { do: 'lamp', index: 1, dur: 0.9 },
      { do: 'lamp', index: 3, dur: 1.2 },
      { do: 'wait', dur: 0.6 },
    ],
  },
];

const GHOST_COLOR = 0x7fd8ff;

export class EchoSystem {
  constructor(scene, { onEvent, onFound, onStateChange } = {}) {
    this.scene = scene;
    this.onEvent = onEvent || (() => {});
    this.onFound = onFound || (() => {});
    this.onStateChange = onStateChange || (() => {});
    this.echoes = new Map();
    this.active = null;       // { def, t, paused, ghost, lastStepIndex }
    this.found = new Set();
    this.hintRadius = 2.4;
    this.build();
  }

  build() {
    this.ghostMat = new THREE.MeshStandardMaterial({
      color: GHOST_COLOR,
      emissive: GHOST_COLOR,
      emissiveIntensity: 0.6,
      transparent: true,
      opacity: 0.6,
      depthWrite: false,
      roughness: 0.4,
    });

    for (const def of ECHO_DEFS) {
      // قاعدة مضيئة تشير إلى موضع الأثر
      const marker = new THREE.Mesh(
        new THREE.RingGeometry(1.4, 1.6, 32),
        new THREE.MeshBasicMaterial({ color: GHOST_COLOR, transparent: true, opacity: 0.5, side: THREE.DoubleSide })
      );
      marker.rotation.x = -Math.PI / 2;
      marker.position.set(def.position[0], 0.3, def.position[1]);
      this.scene.add(marker);
      this.echoes.set(def.id, { def, marker, hintSpot: new THREE.Vector2(def.position[0], def.position[1]) });
    }
  }

  // الأثر المتاح للتفاعل عند الاقتراب (أو null)
  nearby(playerPos) {
    let best = null, bestD = Infinity;
    for (const e of this.echoes.values()) {
      const d = Math.hypot(playerPos.x - e.hintSpot.x, playerPos.z - e.hintSpot.y);
      if (d < this.hintRadius && d < bestD) { best = e; bestD = d; }
    }
    return best;
  }

  isFound(id) { return this.found.has(id); }

  markFound(id) { this.found.add(id); }

  // بدء تشغيل أثر، أو متابعة/إيقاف مؤقت لأثر يعمل
  interact(id) {
    const entry = this.echoes.get(id);
    if (!entry) return;
    if (this.active && this.active.def.id === id) {
      this.togglePause();
      return;
    }
    this.start(id);
  }

  start(id) {
    this.stop();
    const entry = this.echoes.get(id);
    if (!entry) return;
    const ghost = this.makeGhost();
    ghost.position.set(entry.def.position[0], 0, entry.def.position[1]);
    this.scene.add(ghost);
    this.active = { def: entry.def, t: 0, paused: false, ghost, stepIdx: -1, stepT: 0 };
    this.stepStart(0);
    this.onStateChange({ playing: true, paused: false, id });
  }

  restart() {
    if (!this.active) return;
    this.start(this.active.def.id);
  }

  togglePause() {
    if (!this.active) return;
    this.active.paused = !this.active.paused;
    this.onStateChange({ playing: true, paused: this.active.paused, id: this.active.def.id });
  }

  stop() {
    if (!this.active) return;
    this.scene.remove(this.active.ghost);
    this.active.ghost.traverse((o) => {
      if (o.geometry) o.geometry.dispose();
    });
    this.active = null;
    this.onStateChange({ playing: false, paused: false, id: null });
  }

  makeGhost() {
    const g = new THREE.Group();
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.18, 12, 10), this.ghostMat);
    head.position.y = 1.67;
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.3, 0.8, 10), this.ghostMat);
    body.position.y = 1.05;
    const legL = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 0.7, 6), this.ghostMat);
    legL.position.set(-0.13, 0.35, 0);
    const legR = legL.clone();
    legR.position.x = 0.13;
    const aura = new THREE.Mesh(
      new THREE.SphereGeometry(0.9, 16, 12),
      new THREE.MeshBasicMaterial({ color: GHOST_COLOR, transparent: true, opacity: 0.08, depthWrite: false })
    );
    aura.position.y = 1.0;
    g.add(head, body, legL, legR, aura);
    g.userData.aura = aura;
    return g;
  }

  stepStart(idx) {
    const a = this.active;
    a.stepIdx = idx;
    a.stepT = 0;
    const step = a.def.steps[idx];
    if (!step) return;
    if (step.do === 'move') {
      a.from = [a.ghost.position.x, a.ghost.position.z];
    }
    if (step.do === 'lamp') this.onEvent('lamp', { echoId: a.def.id, index: step.index });
    if (step.do === 'event') this.onEvent(step.name, { echoId: a.def.id });
  }

  update(dt) {
    const a = this.active;
    if (!a) return;

    // نبض الهالة
    a.ghost.userData.aura.material.opacity = 0.06 + Math.sin(performance.now() * 0.003) * 0.03;
    this.ghostMat.emissiveIntensity = 0.5 + Math.sin(performance.now() * 0.004) * 0.15;

    if (a.paused) return;

    const steps = a.def.steps;
    const step = steps[a.stepIdx];
    if (!step) {
      this.finish();
      return;
    }

    a.stepT += dt;
    const p = Math.min(1, a.stepT / step.dur);

    if (step.do === 'move') {
      const [fx, fz] = a.from;
      const [tx, tz] = step.to;
      const x = fx + (tx - fx) * p;
      const z = fz + (tz - fz) * p;
      a.ghost.position.x = x;
      a.ghost.position.z = z;
      const dx = tx - fx, dz = tz - fz;
      if (Math.hypot(dx, dz) > 0.01) a.ghost.rotation.y = Math.atan2(dx, dz);
      // مشي تمثيلي
      a.ghost.position.y = Math.abs(Math.sin(a.t * 7)) * 0.04;
    }

    a.t += dt;

    if (p >= 1) {
      a.from = [a.ghost.position.x, a.ghost.position.z];
      this.stepStart(a.stepIdx + 1);
    }
  }

  finish() {
    const id = this.active.def.id;
    const wasFound = this.found.has(id);
    this.found.add(id);
    this.stop();
    if (!wasFound) this.onFound(id);
  }

  // هل تحتوي الخطوة الحالية على تفاعل مُرسل للعالم؟ (لاستخدامه في الواجهة)
  currentLabel() {
    if (!this.active) return '';
    return this.active.def.title;
  }

  dispose() {
    this.stop();
    for (const e of this.echoes.values()) {
      e.marker.geometry.dispose();
      e.marker.material.dispose();
      this.scene.remove(e.marker);
    }
    this.echoes.clear();
    this.ghostMat.dispose();
  }
}

// لغز البوابة: تسلسل الإشارات الضوئية.
// القواعد تُستنتج من الأثر فقط: الحارس يُضيء المصابيح بالترتيب الصحيح (0 ثم 2 ثم 1 ثم 3)
// لا يعمل اللوحة إلا بعد رؤية الأثر وتفعيل الآلية الخفية.

export const LAMP_NAMES = ['أزرق', 'أبيض', 'كهرماني', 'أحمر'];

export const SOLUTION = [0, 2, 1, 3];

export class PuzzleSystem {
  constructor({ onStatus } = {}) {
    this.onStatus = onStatus || (() => {});
    this.powered = false;   // الآلية الخفية فُعّلت (من الأثر)
    this.solved = false;
    this.input = [];
  }

  // يُستدعى عند حدث "mechanism" من الأثر
  powerUp() {
    if (this.powered) return;
    this.powered = true;
    this.onStatus({ type: 'powered' });
  }

  press(index) {
    if (this.solved) return { result: 'solved' };
    if (!this.powered) {
      this.onStatus({ type: 'locked' });
      return { result: 'locked' };
    }

    this.input.push(index);
    const pos = this.input.length - 1;

    if (this.input[pos] !== SOLUTION[pos]) {
      // خطأ: تغذية راجعة ثم إعادة الضبط دون تعطيل اللعبة
      const attempt = this.input.slice();
      this.input = [];
      this.onStatus({ type: 'wrong', attempt });
      return { result: 'wrong' };
    }

    if (this.input.length === SOLUTION.length) {
      this.solved = true;
      this.onStatus({ type: 'solved' });
      return { result: 'solved' };
    }

    this.onStatus({ type: 'progress', count: this.input.length });
    return { result: 'ok', count: this.input.length };
  }

  // تحميل حالة محفوظة
  restore({ powered, solved }) {
    this.powered = !!powered;
    this.solved = !!solved;
    this.input = [];
  }

  reset() {
    this.powered = false;
    this.solved = false;
    this.input = [];
  }
}

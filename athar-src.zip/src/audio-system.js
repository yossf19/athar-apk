// نظام صوت مولّد برمجياً بالكامل (Web Audio API) — لا ملفات خارجية ولا تراخيص.

let ctx = null;
let enabled = true;
let ambientNodes = null;

function ensureCtx() {
  if (ctx) return ctx;
  const AC = window.AudioContext || window.webkitAudioContext;
  if (!AC) return null;
  try { ctx = new AC(); } catch (e) { return null; }
  return ctx;
}

// يجب استدعاؤه من داخل حدث لمس/نقر لتجاوز سياسة المتصفح.
export function unlockAudio() {
  const c = ensureCtx();
  if (c && c.state === 'suspended') c.resume().catch(() => {});
}

export function setAudioEnabled(on) {
  enabled = on;
  if (!on) stopAmbient();
}

function tone({ freq = 440, type = 'sine', dur = 0.3, vol = 0.15, slideTo = null, delay = 0 }) {
  const c = ensureCtx();
  if (!c || !enabled) return;
  const t0 = c.currentTime + delay;
  const osc = c.createOscillator();
  const gain = c.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, t0);
  if (slideTo) osc.frequency.exponentialRampToValueAtTime(slideTo, t0 + dur);
  gain.gain.setValueAtTime(0.0001, t0);
  gain.gain.exponentialRampToValueAtTime(vol, t0 + 0.02);
  gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  osc.connect(gain).connect(c.destination);
  osc.start(t0);
  osc.stop(t0 + dur + 0.05);
}

export const sfx = {
  step() {
    tone({ freq: 90 + Math.random() * 25, type: 'triangle', dur: 0.08, vol: 0.05 });
  },
  echo() {
    tone({ freq: 660, type: 'sine', dur: 0.6, vol: 0.12, slideTo: 990 });
    tone({ freq: 990, type: 'sine', dur: 0.8, vol: 0.08, delay: 0.15 });
  },
  panel() {
    tone({ freq: 880, type: 'square', dur: 0.12, vol: 0.06 });
  },
  wrong() {
    tone({ freq: 180, type: 'sawtooth', dur: 0.35, vol: 0.08, slideTo: 120 });
  },
  gate() {
    tone({ freq: 60, type: 'sine', dur: 2.2, vol: 0.2, slideTo: 40 });
    tone({ freq: 520, type: 'triangle', dur: 1.6, vol: 0.06, delay: 0.4, slideTo: 780 });
  },
};

// صوت بيئي خافت: ضجيج منخفض التردد مع تذبذب بطيء.
export function startAmbient() {
  const c = ensureCtx();
  if (!c || !enabled || ambientNodes) return;
  const bufLen = c.sampleRate * 2;
  const buf = c.createBuffer(1, bufLen, c.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < bufLen; i++) data[i] = (Math.random() * 2 - 1) * 0.3;
  const src = c.createBufferSource();
  src.buffer = buf;
  src.loop = true;
  const lp = c.createBiquadFilter();
  lp.type = 'lowpass';
  lp.frequency.value = 260;
  const lfo = c.createOscillator();
  const lfoGain = c.createGain();
  lfo.frequency.value = 0.07;
  lfoGain.gain.value = 0.02;
  const master = c.createGain();
  master.gain.value = 0.035;
  lfo.connect(lfoGain).connect(master.gain);
  src.connect(lp).connect(master).connect(c.destination);
  src.start();
  lfo.start();
  ambientNodes = { src, lfo };
}

export function stopAmbient() {
  if (!ambientNodes) return;
  try { ambientNodes.src.stop(); ambientNodes.lfo.stop(); } catch (e) { /* تجاهل */ }
  ambientNodes = null;
}

export function pauseAll(paused) {
  if (!ctx) return;
  if (paused) ctx.suspend().catch(() => {});
  else ctx.resume().catch(() => {});
}

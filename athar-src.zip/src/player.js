import * as THREE from 'three';
import { HALF } from './world.js';

// شخصية مؤقتة من أشكال هندسية منظمة، قابلة للاستبدال لاحقاً بنموذج GLB/glTF.
const RADIUS = 0.35;
const MAX_SPEED = 4.2;
const ACCEL = 14;
const DECEL = 18;
const TURN_SPEED = 12;

export class Player {
  constructor(scene) {
    this.root = new THREE.Group();
    this.velocity = new THREE.Vector2(0, 0);
    this.facing = 0;
    this.walkT = 0;
    this.moving = false;

    const bodyMat = new THREE.MeshStandardMaterial({ color: 0x2b4f70, roughness: 0.6, metalness: 0.1 });
    const skinMat = new THREE.MeshStandardMaterial({ color: 0xd9b89a, roughness: 0.7 });
    const trimMat = new THREE.MeshStandardMaterial({ color: 0x7fd8ff, emissive: 0x2a7fb0, emissiveIntensity: 0.4 });

    // الجسم والرأس
    this.torso = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.3, 0.8, 10), bodyMat);
    this.torso.position.y = 1.05;
    this.head = new THREE.Mesh(new THREE.SphereGeometry(0.18, 12, 10), skinMat);
    this.head.position.y = 1.67;
    this.trim = new THREE.Mesh(new THREE.TorusGeometry(0.26, 0.02, 6, 16), trimMat);
    this.trim.rotation.x = Math.PI / 2;
    this.trim.position.y = 0.7;

    // الأطراف: تتأرجح أثناء المشي
    const limbGeo = new THREE.CylinderGeometry(0.07, 0.07, 0.7, 6);
    this.legL = this.makeLimb(limbGeo, bodyMat, -0.13, 0.65);
    this.legR = this.makeLimb(limbGeo, bodyMat, 0.13, 0.65);
    this.armL = this.makeLimb(limbGeo, bodyMat, -0.36, 1.25);
    this.armR = this.makeLimb(limbGeo, bodyMat, 0.36, 1.25);

    this.root.add(this.torso, this.head, this.trim);
    scene.add(this.root);

    this.position = this.root.position;
    this.position.set(2, 0, 24); // نقطة الاستيقاظ في الحي الصامت
  }

  makeLimb(geo, mat, x, pivotY) {
    const pivot = new THREE.Group();
    pivot.position.set(x, pivotY, 0);
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.y = -0.35;
    pivot.add(mesh);
    this.root.add(pivot);
    return pivot;
  }

  // يتحقق مما إذا كانت النقطة داخل أي جدار (مع نصف القطر)
  collides(x, z, colliders) {
    for (const c of colliders) {
      if (x + RADIUS > c.minX && x - RADIUS < c.maxX && z + RADIUS > c.minZ && z - RADIUS < c.maxZ) {
        return true;
      }
    }
    return false;
  }

  // input: { x, z } في فضاء الشاشة، cameraYaw لتحويل الحركة لاتجاه الكاميرا
  update(dt, input, cameraYaw, colliders) {
    const mag = Math.min(1, Math.hypot(input.x, input.z));
    let targetX = 0, targetZ = 0;
    if (mag > 0.05) {
      const dirX = input.x, dirZ = input.z;
      // الأمام = اتجاه النظر بعيداً عن الكاميرا، واليمين = عمودي عليه
      // الكاميرا تقع عند (sin yaw, cos yaw)، لذا الأمام = (-sin, -cos) واليمين = (cos, -sin)
      const s = Math.sin(cameraYaw), c = Math.cos(cameraYaw);
      targetX = (dirX * c - dirZ * s) * MAX_SPEED * mag;
      targetZ = (-dirX * s - dirZ * c) * MAX_SPEED * mag;
    }

    // تسارع وتباطؤ بسيطان
    const rate = (targetX || targetZ) ? ACCEL : DECEL;
    const k = 1 - Math.exp(-rate * dt);
    this.velocity.x += (targetX - this.velocity.x) * k;
    this.velocity.y += (targetZ - this.velocity.y) * k;

    const speed = Math.hypot(this.velocity.x, this.velocity.y);
    this.moving = speed > 0.2;

    // حركة مع فصل المحاور لتسمح بالانزلاق على الجدران
    const nx = this.position.x + this.velocity.x * dt;
    const nz = this.position.z + this.velocity.y * dt;
    if (!this.collides(nx, this.position.z, colliders)) this.position.x = nx;
    else this.velocity.x = 0;
    if (!this.collides(this.position.x, nz, colliders)) this.position.z = nz;
    else this.velocity.y = 0;

    // حدود الأرضية كحماية إضافية
    const lim = HALF - 1;
    this.position.x = THREE.MathUtils.clamp(this.position.x, -lim, lim);
    this.position.z = THREE.MathUtils.clamp(this.position.z, -lim, lim);

    // دوران سلس باتجاه الحركة
    if (this.moving) {
      const desired = Math.atan2(this.velocity.x, this.velocity.y);
      let diff = desired - this.facing;
      diff = Math.atan2(Math.sin(diff), Math.cos(diff));
      this.facing += diff * (1 - Math.exp(-TURN_SPEED * dt));
    }
    this.root.rotation.y = this.facing;

    // أنيميشن المشي البديل
    if (this.moving) {
      this.walkT += dt * (6 + speed);
    } else {
      this.walkT *= Math.exp(-8 * dt);
    }
    const swing = Math.sin(this.walkT) * 0.6 * Math.min(1, speed / 2);
    this.legL.rotation.x = swing;
    this.legR.rotation.x = -swing;
    this.armL.rotation.x = -swing * 0.8;
    this.armR.rotation.x = swing * 0.8;
    this.torso.position.y = 1.05 + Math.abs(Math.sin(this.walkT)) * 0.03 * Math.min(1, speed / 2);

    return speed;
  }

  // موقع الخطوة الحالية لتشغيل صوت الخطى عند نقاط محددة من الدورة
  stepPhaseCrossed(prevT, nextT) {
    const a = Math.floor(prevT / Math.PI);
    const b = Math.floor(nextT / Math.PI);
    return a !== b;
  }

  reset(x, z, yaw = 0) {
    this.position.set(x, 0, z);
    this.velocity.set(0, 0);
    this.facing = yaw;
    this.root.rotation.y = yaw;
  }
}

import * as THREE from 'three';
import { buildWorld, colliders } from './world.js';
import { Player } from './player.js';
import { ThirdPersonCamera } from './camera.js';
import { EchoSystem } from './echo-system.js';
import { PuzzleSystem, LAMP_NAMES } from './puzzle-system.js';
import { loadState, saveState, clearState, hasProgress, storageAvailable } from './save-system.js';
import { sfx, startAmbient, stopAmbient, setAudioEnabled, unlockAudio, pauseAll } from './audio-system.js';
import { ui } from './ui.js';

const GATE_POS = { x: 0, z: -26 };
const PANEL_POS = { x: -3.6, z: -22.5 };
const PANEL_RANGE = 2.4;
const QUALITY = {
  low: { pixel: 0.75 },
  medium: { pixel: 1.0 },
  high: { pixel: 1.5 },
};
const SENS_CYCLE = [0.6, 1, 1.6];

export class Game {
  constructor(canvas) {
    this.canvas = canvas;
    ui.init();
    this.state = loadState();
    this.running = false;
    this.paused = false;
    this.lastTime = 0;
    this.input = { x: 0, z: 0 };
    this.keys = new Set();
    this.joyPointer = null;
    this.lookPointer = null;
    this.lastEchoId = null;
    this.gateOpening = false;
    this.gateCollider = null;
    this.lampTimers = [];
    this.loopId = null;

    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.NoToneMapping; // الألوان تبقى واضحة وزاهية
    this.renderer.toneMappingExposure = 1;

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(55, 1, 0.1, 200);
    this.rig = new ThirdPersonCamera(this.camera);

    this.applySettings(this.state.settings, false);
    this.world = buildWorld(this.scene, this.state.settings.quality);
    this.player = new Player(this.scene); // يبدأ عند (2, 24)

    this.puzzle = new PuzzleSystem({ onStatus: (s) => this.onPuzzleStatus(s) });
    this.echo = new EchoSystem(this.scene, {
      onEvent: (name, data) => this.onEchoEvent(name, data),
      onFound: (id) => this.onEchoFound(id),
      onStateChange: () => {},
    });

    this.restoreWorld();
    this.bindUI();
    this.bindInput();
    this.resize();
  }

  // ---------- الإعدادات والجودة ----------
  applySettings(s, persist = true) {
    this.state.settings = { ...this.state.settings, ...s };
    const q = QUALITY[this.state.settings.quality] || QUALITY.medium;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.renderer.setPixelRatio(dpr * q.pixel);
    this.renderer.shadowMap.enabled = this.state.settings.quality !== 'low';
    this.renderer.shadowMap.type = THREE.PCFShadowMap;
    this.rig.sensitivity = this.state.settings.sensitivity;
    setAudioEnabled(this.state.settings.audio);
    ui.setSensLabel(this.state.settings.sensitivity);
    if (persist) this.save();
  }

  // ---------- الحفظ ----------
  save() {
    saveState(this.state); // يفشل بصمت إن كان التخزين معطلاً
  }

  restoreWorld() {
    const s = this.state;
    for (const id of Object.keys(s.echoesFound)) this.echo.markFound(id);
    this.puzzle.restore({ powered: s.puzzlePowered, solved: s.puzzleSolved });
    if (s.gateOpen) this.setGateOpenVisual(true);
  }

  // ---------- الربط بالواجهة والمدخلات ----------
  bindUI() {
    ui.writeSettings(this.state.settings);
    ui.setReplayAvailable(false);

    const hasSave = hasProgress(this.state);
    ui.setVisible('btn-reset-title', hasSave);
    ui.hide('btn-continue');
    ui.showOnly('title-screen');

    ui.el['btn-start'].addEventListener('click', () => this.begin());
    ui.el['btn-reset-title'].addEventListener('click', () => this.hardReset());
    ui.el['btn-pause'].addEventListener('click', () => this.pause());
    ui.el['btn-resume'].addEventListener('click', () => this.resume());
    ui.el['btn-reset'].addEventListener('click', () => this.hardReset());
    ui.el['btn-success-close'].addEventListener('click', () => this.resume());
    ui.el['btn-puzzle-close'].addEventListener('click', () => ui.closePuzzle());
    ui.el['btn-interact'].addEventListener('click', () => this.interact());
    ui.el['btn-replay'].addEventListener('click', () => this.replay());
    ui.el['btn-sens'].addEventListener('click', () => this.cycleSensitivity());

    ui.el['set-audio'].addEventListener('change', (e) => this.applySettings({ audio: e.target.checked }));
    ui.el['set-sens'].addEventListener('change', (e) => this.applySettings({ sensitivity: parseFloat(e.target.value) }));
    ui.el['set-quality'].addEventListener('change', (e) => {
      this.applySettings({ quality: e.target.value });
      ui.toast('تم تغيير الجودة. قد تحتاج الإعدادات الكاملة إلى إعادة تشغيل.', 2600);
    });

    document.querySelectorAll('.lamp-btn').forEach((btn) => {
      btn.addEventListener('click', () => this.pressLamp(parseInt(btn.dataset.lamp, 10)));
    });

    if (!storageAvailable) {
      ui.toast('التخزين المحلي غير متاح؛ لن يُحفظ التقدم في هذا المتصفح.', 4500, 'bad');
    }
  }

  bindInput() {
    // لوحة المفاتيح (للحاسوب مستقبلاً)
    window.addEventListener('keydown', (e) => {
      unlockAudio();
      this.keys.add(e.code);
      if (e.code === 'KeyE') this.interact();
      if (e.code === 'Escape' || e.code === 'KeyP') this.paused ? this.resume() : this.pause();
    });
    window.addEventListener('keyup', (e) => this.keys.delete(e.code));
    window.addEventListener('blur', () => this.keys.clear());

    // العصا الافتراضية
    const joy = ui.el['joystick'];
    const knob = ui.el['joystick-knob'];
    const radius = () => joy.clientWidth * 0.36;
    const setKnob = (dx, dy) => {
      knob.style.transform = `translate(${dx}px, ${dy}px)`;
    };
    joy.addEventListener('pointerdown', (e) => {
      unlockAudio();
      this.joyPointer = e.pointerId;
      joy.setPointerCapture(e.pointerId);
      e.preventDefault();
    });
    joy.addEventListener('pointermove', (e) => {
      if (e.pointerId !== this.joyPointer) return;
      const r = joy.getBoundingClientRect();
      let dx = e.clientX - (r.left + r.width / 2);
      let dy = e.clientY - (r.top + r.height / 2);
      const len = Math.hypot(dx, dy);
      const max = radius();
      if (len > max) { dx = dx / len * max; dy = dy / len * max; }
      setKnob(dx, dy);
      // الأمام = سحب للأعلى
      this.input.x = dx / max;
      this.input.z = -dy / max;
    });
    const endJoy = (e) => {
      if (e.pointerId !== this.joyPointer) return;
      this.joyPointer = null;
      setKnob(0, 0);
      this.input.x = 0;
      this.input.z = 0;
    };
    joy.addEventListener('pointerup', endJoy);
    joy.addEventListener('pointercancel', endJoy);

    // سحب منطقة الكاميرا (اليمين)
    const look = ui.el['look-zone'];
    look.style.pointerEvents = 'auto';
    look.addEventListener('pointerdown', (e) => {
      unlockAudio();
      this.lookPointer = { id: e.pointerId, x: e.clientX, y: e.clientY };
      look.setPointerCapture(e.pointerId);
    });
    look.addEventListener('pointermove', (e) => {
      if (!this.lookPointer || e.pointerId !== this.lookPointer.id) return;
      const dx = e.clientX - this.lookPointer.x;
      const dy = e.clientY - this.lookPointer.y;
      this.lookPointer.x = e.clientX;
      this.lookPointer.y = e.clientY;
      this.rig.rotate(dx, dy);
    });
    const endLook = (e) => {
      if (this.lookPointer && e.pointerId === this.lookPointer.id) this.lookPointer = null;
    };
    look.addEventListener('pointerup', endLook);
    look.addEventListener('pointercancel', endLook);

    window.addEventListener('resize', () => this.resize());
    window.addEventListener('orientationchange', () => setTimeout(() => this.resize(), 200));
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) this.pause();
    });
  }

  resize() {
    const w = window.innerWidth, h = window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.rig.setAspect(w / Math.max(1, h));
  }

  // ---------- دورة اللعب ----------
  begin() {
    unlockAudio();
    ui.showOnly(null);
    ui.show('hud');
    this.running = true;
    this.paused = false;
    startAmbient();
    this.refreshObjective();
    this.lastTime = performance.now();
    this.loopId = requestAnimationFrame((t) => this.frame(t));
    ui.toast('استيقظتَ في حي صامت. المدينة تتذكّر شيئاً ما.', 4000);
  }

  pause() {
    if (!this.running || this.paused) return;
    this.paused = true;
    ui.show('pause-screen');
    pauseAll(true);
    stopAmbient();
    this.input = { x: 0, z: 0 };
  }

  resume() {
    if (!this.running) return;
    ui.hide('success-screen');
    ui.hide('pause-screen');
    this.paused = false;
    pauseAll(false);
    startAmbient();
    this.lastTime = performance.now();
  }

  frame(now) {
    this.loopId = requestAnimationFrame((t) => this.frame(t));
    const dt = Math.min(0.05, (now - this.lastTime) / 1000);
    this.lastTime = now;
    if (this.paused) {
      this.renderer.render(this.scene, this.camera);
      return;
    }
    this.update(dt);
    this.renderer.render(this.scene, this.camera);
  }

  update(dt) {
    // مدخلات لوحة المفاتيح
    let kx = 0, kz = 0;
    if (this.keys.has('KeyW') || this.keys.has('ArrowUp')) kz += 1;
    if (this.keys.has('KeyS') || this.keys.has('ArrowDown')) kz -= 1;
    if (this.keys.has('KeyD') || this.keys.has('ArrowRight')) kx += 1;
    if (this.keys.has('KeyA') || this.keys.has('ArrowLeft')) kx -= 1;

    const ix = this.joyPointer !== null ? this.input.x : kx;
    const iz = this.joyPointer !== null ? this.input.z : kz;

    const prevT = this.player.walkT;
    const speed = this.player.update(dt, { x: ix, z: iz }, this.rig.yaw, colliders);
    if (speed > 1 && this.player.stepPhaseCrossed(prevT, this.player.walkT)) sfx.step();

    this.rig.update(dt, this.player.position, colliders);
    this.echo.update(dt);
    this.updateGate(dt);
    this.updateProximity();
  }

  updateGate(dt) {
    if (!this.gateOpening) return;
    const { doorL, doorR, seamMat } = this.world;
    doorL.position.x += (-3.4 - doorL.position.x) * (1 - Math.exp(-2.2 * dt));
    doorR.position.x += (3.4 - doorR.position.x) * (1 - Math.exp(-2.2 * dt));
    seamMat.opacity *= Math.exp(-1.5 * dt);
    if (Math.abs(doorL.position.x + 3.4) < 0.02) {
      this.gateOpening = false;
      this.world.glowLight.intensity = 2.6;
    }
  }

  // يُستدعى عند استعادة حالة مفتوحة: الأبواب في مكانها النهائي والتصادم مزال
  setGateOpenVisual(open) {
    if (!open) return;
    const { doorL, doorR, seamMat } = this.world;
    doorL.position.x = -3.4;
    doorR.position.x = 3.4;
    seamMat.opacity = 0;
    this.removeGateCollider();
  }

  removeGateCollider() {
    const i = colliders.findIndex((c) => c.minZ === -26.5 && c.maxX === 3.8);
    if (i >= 0) colliders.splice(i, 1);
  }

  // التلميحات والأزرار حسب القرب
  updateProximity() {
    const pos = this.player.position;
    const echo = this.echo.nearby(pos);
    const nearPanel = Math.hypot(pos.x - PANEL_POS.x, pos.z - PANEL_POS.z) < PANEL_RANGE;
    const playing = !!this.echo.active;

    let hint = null, label = 'تفاعل';
    if (playing) {
      label = this.echo.active.paused ? 'متابعة' : 'إيقاف مؤقت';
    } else if (echo) {
      hint = `اضغط تفاعل لفحص ${echo.def.title}`;
      label = 'فحص الأثر';
    } else if (nearPanel && !this.state.puzzleSolved) {
      hint = 'لوحة التحكم بالبوابة';
      label = 'لوحة التحكم';
    }

    ui.setHint(!!hint, hint || '');
    ui.setInteractLabel(label);
    ui.setReplayAvailable(!!this.lastEchoId && !playing);
  }

  // ---------- التفاعل ----------
  interact() {
    if (!this.running || this.paused) return;
    unlockAudio();
    if (this.echo.active) {
      this.echo.togglePause();
      sfx.panel();
      return;
    }
    const pos = this.player.position;
    const echo = this.echo.nearby(pos);
    if (echo) {
      this.lastEchoId = echo.def.id;
      this.echo.interact(echo.def.id);
      sfx.echo();
      this.refreshObjective();
      return;
    }
    if (Math.hypot(pos.x - PANEL_POS.x, pos.z - PANEL_POS.z) < PANEL_RANGE) {
      this.openPanel();
    }
  }

  replay() {
    if (!this.running || this.paused || !this.lastEchoId || this.echo.active) return;
    this.echo.interact(this.lastEchoId);
    sfx.echo();
  }

  openPanel() {
    if (this.state.puzzleSolved) {
      ui.toast('البوابة مفتوحة بالفعل.');
      return;
    }
    if (!this.puzzle.powered) {
      sfx.wrong();
      ui.toast('اللوحة خامدة. ربما يكشف الأثر سرّ تشغيلها.', 3800, 'bad');
      return;
    }
    ui.openPuzzle('أدخل الإشارات بالترتيب الصحيح.');
  }

  pressLamp(index) {
    if (this.state.puzzleSolved) return;
    unlockAudio();
    const r = this.puzzle.press(index);
    sfx.panel();
    ui.flashLamp(index);
    this.flashWorldLamp(index, 0.4);
    if (r.result === 'ok') this.refreshObjective();
  }

  flashWorldLamp(index, dur) {
    const lamp = this.world.lamps[index];
    if (!lamp) return;
    lamp.material.emissiveIntensity = 2.2;
    const t = setTimeout(() => { lamp.material.emissiveIntensity = 0; }, dur * 1000);
    this.lampTimers.push(t);
  }

  // ---------- أحداث الأثر واللغز ----------
  onEchoEvent(name, data) {
    if (name === 'lamp') {
      this.flashWorldLamp(data.index, 0.7);
      sfx.panel();
      return;
    }
    if (name === 'mechanism') {
      sfx.gate();
      this.puzzle.powerUp();
      this.state.puzzlePowered = true;
      this.save();
      this.refreshObjective();
      ui.toast('سمعتَ آلية تتحرك تحت اللوحة. اللوحة تعمل الآن.', 4200, 'good');
    }
  }

  onEchoFound(id) {
    this.state.echoesFound[id] = true;
    this.save();
    this.refreshObjective();
    ui.toast('تم تسجيل الأثر. الطريق إلى اللوحة واضح.', 3200, 'good');
  }

  onPuzzleStatus(s) {
    switch (s.type) {
      case 'locked':
        ui.setPuzzleStatus('اللوحة خامدة. شاهد الأثر أولاً.', 'bad');
        break;
      case 'progress':
        ui.setPuzzleStatus(`جيد. الإشارة ${s.count} من 4 صحيحة.`, 'good');
        break;
      case 'wrong':
        sfx.wrong();
        ui.setPuzzleStatus('ترتيب خاطئ. أُعيد ضبط الإشارات، حاول مجدداً.', 'bad');
        break;
      case 'solved':
        this.openGate();
        break;
      case 'powered':
        break;
    }
  }

  openGate() {
    this.state.puzzleSolved = true;
    this.state.gateOpen = true;
    this.save();
    ui.closePuzzle();
    sfx.gate();
    this.gateOpening = true;
    this.removeGateCollider();
    this.refreshObjective();
    setTimeout(() => {
      // شاشة النجاح تُوقف اللعب مؤقتاً حتى يتابع اللاعب
      this.paused = true;
      pauseAll(true);
      stopAmbient();
      ui.show('success-screen');
    }, 2600);
  }

  refreshObjective() {
    const s = this.state;
    let name = 'الفصل الأول: الحي الصامت';
    let obj = 'استكشف الحي واعثر على أثر يفسّر البوابة.';
    if (s.gateOpen) {
      name = 'الفصل الثاني: ما وراء البوابة';
      obj = 'انفتحت البوابة. المدينة تنتظرك.';
    } else if (s.puzzlePowered) {
      obj = 'ادخل إلى لوحة التحكم وأدخل الإشارات بالترتيب الذي رأيته.';
    } else if (Object.keys(s.echoesFound).length > 0) {
      obj = 'ابحث عن الآلية التي ذكرها الأثر.';
    } else if (this.lastEchoId) {
      obj = 'شاهد الأثر حتى نهايته.';
    }
    ui.setChapter(name, obj);
    ui.setReplayAvailable(!!this.lastEchoId && !this.echo.active);
  }

  hardReset() {
    const ok = window.confirm('سيتم حذف التقدم المحفوظ على هذا المتصفح. هل أنت متأكد؟');
    if (!ok) return;
    clearState();
    stopAmbient();
    window.location.reload();
  }

  cycleSensitivity() {
    const cur = this.state.settings.sensitivity;
    const i = SENS_CYCLE.indexOf(cur);
    const next = SENS_CYCLE[(i + 1) % SENS_CYCLE.length];
    this.applySettings({ sensitivity: next });
    ui.writeSettings(this.state.settings);
    ui.toast(`حساسية الكاميرا: ${next === 0.6 ? 'منخفضة' : next === 1 ? 'متوسطة' : 'مرتفعة'}`, 1600);
  }

  dispose() {
    cancelAnimationFrame(this.loopId);
    this.echo.dispose();
    this.renderer.dispose();
    this.lampTimers.forEach(clearTimeout);
  }
}

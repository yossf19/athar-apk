import './style.css';
import { Game } from './game.js';
import { ui } from './ui.js';

// فحص دعم WebGL قبل أي شيء آخر
function webglSupported() {
  try {
    const c = document.createElement('canvas');
    return !!(window.WebGLRenderingContext && (c.getContext('webgl2') || c.getContext('webgl')));
  } catch (e) {
    return false;
  }
}

function boot() {
  ui.init();

  if (!webglSupported()) {
    ui.showOnly('no-webgl');
    return;
  }

  // تسجيل أخطاء الموارد دون إسقاط اللعبة
  window.addEventListener('error', (e) => {
    console.error('[athar] خطأ غير متوقع:', e.message);
  });

  const canvas = document.getElementById('game-canvas');
  let game;
  try {
    game = new Game(canvas);
  } catch (err) {
    console.error('[athar] تعذّر إنشاء اللعبة:', err);
    ui.showOnly('no-webgl');
    return;
  }

  // زر البداية يحمل معه تفعيل الصوت (يتطلب حدث مستخدم)
  window.__athar = game; // للتشخيص أثناء التطوير فقط
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', boot);
} else {
  boot();
}
